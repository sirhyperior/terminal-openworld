# Project Status

Last reviewed: **2026-11-13**. Standing rules: [AGENTS.md](AGENTS.md).
User backlog: [backlog.md](backlog.md). Launch/controls: [README.md](README.md).

## Current checkpoint

- **Rollback and standing-rule checkpoint: a2049c3.** Uncommitted color/shading
  work and associated optimizations/tools were restored through Git to fd56e49.
  White ASCII on black is restored. Color remains deferred; do not restart it
  without a new request. Abandoned data stays only in
  `benchmarks/abandoned-color-2026-11-13.zip`, not active code or baselines.
- AGENTS.md explicitly permits subagents whenever helpful, without another
  permission request. That rule is committed in a2049c3.
- **Richer loading presentation is implemented and verified.** Startup has a
  title card, activity spinner, completed-phase bar, rotating gameplay tips and
  wide-window elapsed seconds. Compact layouts keep whole bars/tips. Percentages
  still count the original six completed phases. Loading writes serialize with
  terminal entry; animation stops before gameplay or restoration, including
  interrupted/failed startup. Headless modes create no animation worker.
- **Automatic block climbing is fixed.** Only continuous terrain and authored
  stair treads permit upward walking support. Ordinary blocks require jumping;
  standing, descent, landing and generic item/camera support remain available.
  All 13 stair flights retain traversal and their contact Foley.
- The completed loading and block-climbing entries are removed from the backlog.
  Their implementations/tests/docs remain uncommitted pending user play review,
  per the repository Git rule. No color, dependency, map geometry, input binding
  or sound synthesis changes were introduced in these two fixes.
- Approved GPU integration remains optional, with float64 refinement and exact
  CPU fallback. `--renderer auto|cpu|gpu` and `.venv-gpu` support remain. Optional
  wgpu 0.33.0 requires Python 3.11+; dependency-free CPU targets Python 3.10+
  (3.10 execution remains unverified).

## Latest verification

- **435 native-console tests pass** on the initial loading presentation, zero
  failures/errors, one sandbox cursor skip, including real GPU/input checks.
  After compact-layout and main-screen-line cleanup, **38 final loading/game-loop
  checks pass**, including terminal/audio entry failures, interruption, headless
  behavior and output sizing at 60/80/100/120/160 columns.
- Actual **120x30 native GPU app**, **30 demo frames with live sound**, exit 0.
  Loading animates through completed percentages 0/16/33/50/66/83/100; 100 appears
  once. Three tips rotate over about eight seconds. No loading worker exists
  during any game frame or after shutdown. Audio has zero underruns/recoveries,
  maximum refill interval **59.10 ms**. Final engine hashes remain unchanged.
  This validates startup/lifecycle, not visible-terminal FPS or speaker quality.
- Movement reference: **429 native tests** passed before loading work. All 13
  flights: **52 grounded/noncolliding walking/sprinting legs**, exactly **1,040
  contact cues**. Six castle obstruction cases, fractional terrain/solids,
  explicit jumps, descent and item settling have regression coverage.
- Movement's matched **120x40/60-frame/live-audio CPU ABBA** against a2049c3 passed
  **34/34** roles, largest mean/p95 increases **3.07%/8.38%**, zero underruns or
  recoveries. Loading work changes startup presentation only; no new gameplay
  frame-time baseline is claimed or historical gate relaxed.
- Temporary native runner and generated caches are removed. No validation jobs
  remain active. Detailed evidence: [loading](benchmarks/loading-screen-2026-11-13.md),
  [movement](benchmarks/block-climbing-2026-11-13.md).

## Open work and limits

1. User play review of loading/movement in the actual terminal is still needed.
   Physical mouse capture in the user's tabbed terminal, speaker/reconnect
   quality, POSIX held keys and Python 3.10 remain unverified. The standalone
   audio diagnostic was not rerun.
2. Historical performance acceptance remains open: the last d20cd0d GPU comparison
   (2026-11-12) passed 14/24 roles. A measured CPU/GPU selection policy remains
   proposed, not implemented. These startup/movement checks do not replace that
   original comparison.
3. Remaining non-color priorities: optimization, themed map redesign and remaining
   blockiness. No save/load or objectives. Partial-Z edits through sloped terrain
   still replace whole XY cells.

Earlier controls: [2026-11-12 evidence](benchmarks/smooth-performance-2026-11-12.md),
[benchmark index](benchmarks/README.md).

## Resume commands

Use a native console for input coverage. Desktop cursor opt-in may skip in the
restricted workspace. Run timing jobs serially with unused report paths.

```powershell
$env:TMP=$PWD.Path; $env:TEMP=$PWD.Path
$env:MONOLITH_GPU_TESTS='1'; $env:MONOLITH_DESKTOP_TESTS='1'
.\.venv-gpu\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv-gpu\Scripts\python.exe -B main.py --renderer gpu
python -B main.py --renderer cpu --keyboard-look
# West merlon: (31.5,38.5,Z6), yaw pi; W stays at Z6, Space can reach Z7.
# Historical control, reconstruct only if absent:
git archive --format=zip --output=smooth-control-tmp.zip d20cd0d ascii3d
Expand-Archive -LiteralPath smooth-control-tmp.zip -DestinationPath smooth_control_tmp
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_pair.py --before-source smooth_control_tmp --before-elevated-audio --after-renderer gpu --frames 60 --audio --save benchmarks/gpu-next-unused.json
# The separate smooth-geometry control is a3d044f.
```
