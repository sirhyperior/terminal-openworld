The following is NOT listed according to priority, but the user may choose a certain task to operate on at present time.
When a milestone is complete, remove it from the list and reassign the numbering to any remaining tasks.

1. Remake map - redesign landmarks to align with theme, rearrange across map. You may remove/replace enemies and structures to achieve this.
2. Optimization - optimization still seems to remain a big priority. frame rates are still not ideal, especially in full screen. see what you can do.
3. remove "blockiness" - parts of the world still feel blocky and made of squares/rectangles. i want this gone. make everything look natural.
4. Color - deferred at the user's request. Keep white ASCII on black for now and work on other priorities.
6. sever lag spike near 215.2,187.4, 10.0
7. Completely revamp sound effects - again, make things align with the dark fantasy theme.
