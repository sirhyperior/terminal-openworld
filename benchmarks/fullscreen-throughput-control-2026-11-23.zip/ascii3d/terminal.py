"""Terminal lifecycle and nonblocking keyboard input; no third-party packages."""

from dataclasses import dataclass, field
import math
import os
import shutil
import sys
import time

from .presentation import StyledFrame, encode_ansi_row


def _changed_spans(previous, current, width):
    """Compare short cell blocks, combining nearby changes into one write."""
    if previous == current:
        return
    if previous is None or width <= 16:
        yield 0, width
        return
    buffers = [(before, after) for before, after in zip(previous, current) if before != after]
    # Optional color planes can appear or disappear between styled frames.
    if any(before is None or after is None for before, after in buffers):
        yield 0, width
        return
    start = stop = None
    for left in range(0, width, 16):
        right = min(width, left + 16)
        if not any(before[left:right] != after[left:right] for before, after in buffers):
            continue
        if stop is not None and left > stop + 16:
            yield start, stop
            start = None
        if start is None:
            start = left
        stop = right
    if start is not None:
        yield start, stop


def fit_viewport(columns: int, rows: int, max_cells: int | None = None) -> tuple[int, int]:
    """Use every native text cell unless an explicit render budget is supplied."""
    width, height = max(1, columns), max(1, rows)
    if max_cells is not None and width * height > max_cells:
        minimum_width, minimum_height = min(width, 60), min(height, 20)
        scale = math.sqrt(max_cells / (width * height))
        width = max(minimum_width, int(width * scale))
        height = max(minimum_height, int(height * scale))
        if width * height > max_cells:
            width = max(minimum_width, max_cells // height)
        if width * height > max_cells:
            height = max(minimum_height, max_cells // width)
    return width, height


@dataclass
class Keys:
    """Gameplay state and ordered editor input when the console has focus."""

    down: set[str] = field(default_factory=set)
    pressed: set[str] = field(default_factory=set)
    mouse_dx: float = 0.0
    mouse_dy: float = 0.0
    text_events: tuple[str, ...] = ()


class _WindowsPointer:
    """Small Win32 seam; all pointer ownership is handled by WindowsMouse."""

    supports_raw_mouse = True

    def __init__(self, kernel):
        import ctypes
        from ctypes import wintypes as wt

        self.ctypes, self.wt = ctypes, wt
        self.kernel, self.relative_capture = kernel, None
        self.capture_error = ""
        self.api = ctypes.WinDLL("user32", use_last_error=True)
        kernel.GetConsoleWindow.restype = wt.HWND
        self.console_window = kernel.GetConsoleWindow()
        self.api.GetForegroundWindow.restype = wt.HWND
        self.api.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        self.api.GetClientRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        self.api.ClientToScreen.argtypes = [wt.HWND, ctypes.POINTER(wt.POINT)]
        self.api.GetCursorPos.argtypes = [ctypes.POINTER(wt.POINT)]
        self.api.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        self.api.GetClipCursor.argtypes = [ctypes.POINTER(wt.RECT)]
        self.api.ClipCursor.argtypes = [ctypes.POINTER(wt.RECT)]
        self.api.IsIconic.argtypes = [wt.HWND]
        self.api.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.api.GetAsyncKeyState.restype = wt.SHORT

    def foreground(self):
        return self.api.GetForegroundWindow()

    def is_terminal(self, window):
        if not window:
            return False
        if window == self.console_window:
            return True
        name = self.ctypes.create_unicode_buffer(128)
        self.api.GetClassNameW(window, name, len(name))
        return name.value in ("CASCADIA_HOSTING_WINDOW_CLASS", "ConsoleWindowClass")

    def minimized(self, window):
        return bool(self.api.IsIconic(window))

    def rect(self, window):
        rect = self.wt.RECT()
        if not self.api.GetClientRect(window, self.ctypes.byref(rect)):
            return None
        low, high = self.wt.POINT(rect.left, rect.top), self.wt.POINT(rect.right, rect.bottom)
        if not (self.api.ClientToScreen(window, self.ctypes.byref(low))
                and self.api.ClientToScreen(window, self.ctypes.byref(high))):
            return None
        return low.x, low.y, high.x, high.y

    def cursor(self):
        point = self.wt.POINT()
        return (point.x, point.y) if self.api.GetCursorPos(self.ctypes.byref(point)) else None

    def clip(self):
        rect = self.wt.RECT()
        if self.api.GetClipCursor(self.ctypes.byref(rect)):
            return rect.left, rect.top, rect.right, rect.bottom
        return None

    def set_clip(self, rect):
        bounds = self.wt.RECT(*rect) if rect is not None else None
        return bool(self.api.ClipCursor(self.ctypes.byref(bounds) if bounds is not None else None))

    def move(self, x, y):
        return bool(self.api.SetCursorPos(x, y))

    def button_down(self):
        # Async state and Raw Input both use physical buttons. Match the
        # logical primary click when Windows' left/right preference is swapped.
        return self.key_down(0x02 if self.api.GetSystemMetrics(23) else 0x01)

    def key_down(self, virtual_key):
        return bool(self.api.GetAsyncKeyState(virtual_key) & 0x8000)

    def hide(self):
        # Best effort: ShowCursor changes this GUI thread's display counter.
        # A separate console/Windows Terminal host owns its own counter, so it
        # may keep its pointer visible. Do not attach host input queues or
        # replace system cursors merely to hide it; balance only our own calls.
        count = 0
        while count < 16:
            count += 1
            if self.api.ShowCursor(False) < 0:
                break
        return count

    def show(self, count):
        for _ in range(count):
            self.api.ShowCursor(True)

    def start_relative(self, window, bounds):
        from .mouse_capture import NativeMouseCapture

        original_clip, original_cursor = self.clip(), self.cursor()
        self.capture_error = ""
        try:
            if self.relative_capture is None:
                self.relative_capture = NativeMouseCapture(self.kernel, self.api)
            if self.relative_capture.start(window, bounds, self.button_down()):
                return True
        except OSError as error:
            self.capture_error = str(error)
        # Acquisition is transactional: a failed warp/registration must never
        # leave a one-pixel clip or input window behind.
        if self.relative_capture is not None:
            if not self.capture_error:
                self.capture_error = self.relative_capture.error
            self.relative_capture.stop()
            if self.clip() == self.relative_capture.clip:
                self.set_clip(original_clip)
        if self.foreground() == window and original_cursor is not None:
            self.move(*original_cursor)
        return False

    def close(self):
        if self.relative_capture is not None:
            self.relative_capture.close()
            self.relative_capture = None


class WindowsMouse:
    """Relative look without screen-edge limits, restricted to our terminal.

    Windows Terminal's console handle is a hidden compatibility window. An
    fresh console click with its physical button still held identifies its host
    before capture; focus records alone never identify another foreground app.
    """

    def __init__(self, pointer):
        self.pointer = pointer
        self.requested = self.captured = False
        self.window = None
        self.bounds = self.center = None
        self.original_clip = self.original_cursor = None
        self.hide_count = 0
        self.raw_relative = False
        self.capture_clip = None
        self._raw_attack = False
        self.left_down = False
        self._recovered_press = False
        self._blurred = False
        self._release_pending = False
        self._release_restore_cursor = False
        self.release_error = ""

    def confirm_focus(self):
        if not self.requested:
            return
        foreground = self.pointer.foreground()
        if self.captured:
            if foreground != self.window:
                self.focus_lost()
            return
        if self.window is None and foreground == self.pointer.console_window:
            self.window = foreground

    def focus_lost(self):
        self.release(restore_cursor=False)
        self.requested = False
        self.left_down = False
        self._blurred = True

    def set_capture(self, active):
        self.requested = bool(active)
        if not active:
            self.release()
            return
        # A classic console has an unambiguous foreground HWND. Modern terminal
        # hosts need their own input event before we can safely identify them.
        if self.window is None and self.pointer.foreground() == self.pointer.console_window:
            self.confirm_focus()
        self._acquire()

    def _acquire(self):
        if self.captured or not self.requested or self.window is None:
            return
        if self._release_pending:
            # Never replace the saved desktop clip with our unreleased clip.
            # Retry once, then let a later poll establish a fresh capture.
            self._restore_clip()
            return
        if self.pointer.foreground() != self.window or self.pointer.minimized(self.window):
            return
        bounds, cursor = self.pointer.rect(self.window), self.pointer.cursor()
        if bounds is None or cursor is None or bounds[2] - bounds[0] < 2 or bounds[3] - bounds[1] < 2:
            return
        original_clip = self.pointer.clip()
        center = ((bounds[0] + bounds[2]) // 2, (bounds[1] + bounds[3]) // 2)
        if getattr(self.pointer, "supports_raw_mouse", False) is True:
            if not self.pointer.start_relative(self.window, bounds):
                return
            self.original_clip, self.original_cursor = original_clip, cursor
            self.bounds, self.center = bounds, center
            self.capture_clip = self.pointer.relative_capture.clip
            self.raw_relative, self.captured = True, True
            self._raw_attack = False
            return
        if not self.pointer.set_clip(bounds):
            return
        if not self.pointer.move(*center):
            self.pointer.set_clip(original_clip)
            return
        self.original_clip, self.original_cursor = original_clip, cursor
        self.bounds, self.center = bounds, center
        self.capture_clip = bounds
        self.hide_count = self.pointer.hide()
        self.left_down = self.pointer.button_down()
        self._recovered_press = False
        self.captured = True

    def button(self, down):
        """Return only a fresh left-down edge; the capture click is consumed."""
        self.confirm_focus()
        if self.requested and self.window is None and down and self.pointer.button_down():
            foreground = self.pointer.foreground()
            bounds, cursor = self.pointer.rect(foreground), self.pointer.cursor()
            if (self.pointer.is_terminal(foreground) and bounds is not None and cursor is not None
                    and bounds[0] <= cursor[0] < bounds[2] and bounds[1] <= cursor[1] < bounds[3]):
                # Only a fresh console click with its physical button still
                # held can identify a modern host. Focus records are not proof.
                self.window = foreground
        # A console packet can arrive after physical sampling recovered its
        # press. Consume that acknowledgement without firing the same click.
        recovered = self._recovered_press
        self._recovered_press = False
        attack = bool(down and not self.left_down and self.captured and not recovered)
        self.left_down = bool(down)
        return attack

    def sample_button(self):
        """Recover held presses independently of the host's motion queue."""
        if not self.captured:
            return False
        if self.raw_relative:
            attack, self._raw_attack = self._raw_attack, False
            return attack
        self.confirm_focus()
        if not self.captured:
            return False
        down = self.pointer.button_down()
        attack = bool(down and not self.left_down)
        self.left_down = down
        if attack:
            self._recovered_press = True
        return attack

    def poll(self):
        if not self.captured:
            blurred, self._blurred = self._blurred, False
            if not blurred:
                self._acquire()
            return 0.0, 0.0, blurred
        if self.pointer.foreground() != self.window or self.pointer.minimized(self.window):
            self.focus_lost()
            self._blurred = False
            return 0.0, 0.0, True
        bounds, cursor = self.pointer.rect(self.window), self.pointer.cursor()
        if (bounds is None or cursor is None
                or bounds[2] - bounds[0] < 2 or bounds[3] - bounds[1] < 2):
            self.focus_lost()
            self._blurred = False
            return 0.0, 0.0, True
        if self.raw_relative:
            capture = self.pointer.relative_capture
            try:
                if bounds != self.bounds:
                    resized = capture.resize(bounds)
                    self.capture_clip = capture.clip
                    if not resized:
                        raise OSError("Mouse capture resize failed")
                    self.bounds = bounds
                dx, dy, self._raw_attack = capture.poll()
            except OSError:
                self.focus_lost()
                self._blurred = False
                return 0.0, 0.0, True
            return dx, dy, False
        if bounds != self.bounds:
            # Resizing changes the center; discard that artificial displacement.
            if not self.pointer.set_clip(bounds):
                self.focus_lost()
                self._blurred = False
                return 0.0, 0.0, True
            self.bounds = bounds
            self.center = ((bounds[0] + bounds[2]) // 2, (bounds[1] + bounds[3]) // 2)
            if not self.pointer.move(*self.center):
                self.focus_lost()
                self._blurred = False
                return 0.0, 0.0, True
            return 0.0, 0.0, False
        dx, dy = cursor[0] - self.center[0], cursor[1] - self.center[1]
        if not self.pointer.move(*self.center):
            self.focus_lost()
            self._blurred = False
            return 0.0, 0.0, True
        return dx, dy, False

    def release(self, restore_cursor=True):
        if not self.captured:
            self._release_restore_cursor &= restore_cursor
            self._restore_clip()
            return
        self.captured = False
        self._release_pending = True
        self._release_restore_cursor = restore_cursor
        try:
            if self.raw_relative:
                capture = self.pointer.relative_capture
                # Native clipping may be normalized or changed by a resize.
                # Save its latest successful readback before hiding the helper.
                self.capture_clip = capture.clip
                capture.stop()
        finally:
            self.raw_relative = False
            self._raw_attack = False
            try:
                self._restore_clip()
            finally:
                self.pointer.show(self.hide_count)
                self.hide_count = 0

    def _restore_clip(self):
        """Retry once per call, retaining ownership only while our clip remains."""
        if not self._release_pending:
            return
        current = self.pointer.clip()
        if current is None:
            self.release_error = "Could not read cursor confinement during release"
            return
        if current != self.capture_clip:
            # Another app owns confinement now; discard our pending restore.
            self._release_pending = False
            self.release_error = ""
            return
        if not self.pointer.set_clip(self.original_clip):
            self.release_error = "Could not restore cursor confinement; release will retry"
            return
        self._release_pending = False
        self.release_error = ""
        if (self._release_restore_cursor and self.pointer.foreground() == self.window
                and self.original_cursor is not None):
            self.pointer.move(*self.original_cursor)


class WindowsKeyboard:
    """Read native console key-down AND key-up records, including real Shift."""

    _text_input = False
    _blocked_by_text: set[str] | None = None
    _TEXT_KEYS = {0x08: "backspace", 0x0D: "enter", 0x21: "page_up", 0x22: "page_down",
                  0x23: "end", 0x24: "home", 0x25: "left", 0x26: "up", 0x27: "right",
                  0x28: "down", 0x2E: "delete"}

    def __init__(self):
        import ctypes
        from ctypes import wintypes as wt

        self.ctypes = ctypes
        self.api = ctypes.WinDLL("kernel32", use_last_error=True)

        class Character(ctypes.Union):
            _fields_ = [("UnicodeChar", wt.WCHAR), ("AsciiChar", ctypes.c_char)]

        class KeyEvent(ctypes.Structure):
            _fields_ = [("bKeyDown", wt.BOOL), ("wRepeatCount", wt.WORD),
                        ("wVirtualKeyCode", wt.WORD), ("wVirtualScanCode", wt.WORD),
                        ("uChar", Character), ("dwControlKeyState", wt.DWORD)]

        class Coord(ctypes.Structure):
            _fields_ = [("X", wt.SHORT), ("Y", wt.SHORT)]

        class MouseEvent(ctypes.Structure):
            _fields_ = [("dwMousePosition", Coord), ("dwButtonState", wt.DWORD),
                        ("dwControlKeyState", wt.DWORD), ("dwEventFlags", wt.DWORD)]

        class EventData(ctypes.Union):
            _fields_ = [("KeyEvent", KeyEvent), ("MouseEvent", MouseEvent), ("FocusEvent", wt.BOOL),
                        ("padding", ctypes.c_byte * 16)]

        class InputRecord(ctypes.Structure):
            _fields_ = [("EventType", wt.WORD), ("Event", EventData)]

        self.api.GetStdHandle.argtypes = [wt.DWORD]
        self.api.GetStdHandle.restype = wt.HANDLE
        self.api.GetConsoleMode.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
        self.api.GetConsoleMode.restype = wt.BOOL
        self.api.SetConsoleMode.argtypes = [wt.HANDLE, wt.DWORD]
        self.api.SetConsoleMode.restype = wt.BOOL
        self.api.GetNumberOfConsoleInputEvents.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
        self.api.GetNumberOfConsoleInputEvents.restype = wt.BOOL
        self.api.ReadConsoleInputW.argtypes = [wt.HANDLE, ctypes.POINTER(InputRecord), wt.DWORD,
                                               ctypes.POINTER(wt.DWORD)]
        self.api.ReadConsoleInputW.restype = wt.BOOL
        self.api.FlushConsoleInputBuffer.argtypes = [wt.HANDLE]
        self.api.FlushConsoleInputBuffer.restype = wt.BOOL
        self.handle = self.api.GetStdHandle(-10)
        self.output = self.api.GetStdHandle(-11)
        mode_in, mode_out = wt.DWORD(), wt.DWORD()
        if not self.api.GetConsoleMode(self.handle, ctypes.byref(mode_in)):
            raise OSError("Open this program in a real terminal, such as Windows Terminal or PowerShell.")
        if not self.api.GetConsoleMode(self.output, ctypes.byref(mode_out)):
            raise OSError("Terminal output is unavailable. Use --snapshot when redirecting output.")
        self.original_input, self.original_output = mode_in.value, mode_out.value
        # Disable line buffering, echo, Quick Edit and VT keyboard translation.
        new_input = (mode_in.value & ~(0x1 | 0x2 | 0x4 | 0x40 | 0x200)) | 0x80 | 0x8 | 0x10
        if not self.api.SetConsoleMode(self.output, mode_out.value | 0x4):
            raise OSError("This terminal does not support ANSI output. Try Windows Terminal.")
        if not self.api.SetConsoleMode(self.handle, new_input):
            self.api.SetConsoleMode(self.output, self.original_output)
            raise ctypes.WinError(ctypes.get_last_error())
        self.records = (InputRecord * 256)()
        self.count = wt.DWORD()
        self.available = wt.DWORD()
        self.down: set[str] = set()
        try:
            self.mouse = WindowsMouse(_WindowsPointer(self.api))
        except BaseException:
            self.api.SetConsoleMode(self.handle, self.original_input)
            self.api.SetConsoleMode(self.output, self.original_output)
            raise
        self.mapping = {0x1B: "escape", 0x20: "space", 0x10: "shift", 0xA0: "shift", 0xA1: "shift",
                        0x25: "left", 0x26: "up", 0x27: "right", 0x28: "down", 0x09: "tab",
                        0x0D: "attack", 0xC0: "console"}
        self.mapping.update({ord(key.upper()): key for key in "wasdemhprf"})

    def poll(self) -> Keys:
        pressed: set[str] = set()
        text_events: list[str] = []
        text_input, blocked = self._text_input, self._blocked_by_text
        api, byref = self.api, self.ctypes.byref
        if not api.GetNumberOfConsoleInputEvents(self.handle, byref(self.available)):
            raise self.ctypes.WinError(self.ctypes.get_last_error())
        # Bound the batch: repeated input cannot starve rendering.
        remaining = min(self.available.value, 1024)
        while remaining:
            if not api.ReadConsoleInputW(self.handle, self.records, min(remaining, 256), byref(self.count)):
                raise self.ctypes.WinError(self.ctypes.get_last_error())
            if not self.count.value:
                break
            remaining -= self.count.value
            for record in self.records[:self.count.value]:
                if record.EventType == 0x10:
                    if record.Event.FocusEvent:
                        self.mouse.confirm_focus()
                    else:
                        self.down.clear()
                        if blocked:
                            blocked.clear()
                        self.mouse.focus_lost()
                        pressed.add("blur")
                    continue
                if record.EventType == 0x2:
                    # Ignore clicks while editing. During raw capture the
                    # helper exclusively owns captured button events.
                    if text_input or self.mouse.raw_relative:
                        continue
                    event = record.Event.MouseEvent
                    # Motion/wheel snapshots are not button transitions. Some
                    # hosts coalesce them; neither recentering nor a stale
                    # motion state may swallow a later real click.
                    if ((event.dwEventFlags == 0 or event.dwEventFlags & 0x2)
                            and self.mouse.button(bool(event.dwButtonState & 0x1))):
                        pressed.add("attack")
                    continue
                if record.EventType != 0x1:
                    continue
                event = record.Event.KeyEvent
                code = event.wVirtualKeyCode
                key = self.mapping.get(code)
                if event.bKeyDown and code == ord("C") and event.dwControlKeyState & 0xC:
                    pressed.add("escape")
                    if text_input:
                        pressed.add("interrupt")
                if key:
                    if event.bKeyDown:
                        if key not in self.down and (not text_input or key == "escape"):
                            pressed.add(key)
                        self.down.add(key)
                    else:
                        self.down.discard(key)
                        if blocked:
                            blocked.discard(key)
                if text_input and event.bKeyDown:
                    token = self._TEXT_KEYS.get(code)
                    if token is None:
                        character = event.uChar.UnicodeChar
                        if " " <= character <= "~":
                            token = character
                    if token is not None:
                        repeats = min(event.wRepeatCount, 1024 - len(text_events))
                        text_events.extend([token] * repeats)
                # Modifier state also catches Shift held before the app started.
                if event.dwControlKeyState & 0x10:
                    self.down.add("shift")
                else:
                    self.down.discard("shift")
                    if blocked:
                        blocked.discard("shift")
        dx, dy, blurred = self.mouse.poll()
        if not text_input and self.mouse.sample_button():
            pressed.add("attack")
        if blurred:
            self.down.clear()
            if blocked:
                blocked.clear()
            pressed.add("blur")
        if "blur" in pressed:
            pressed.discard("attack")
            dx = dy = 0.0
            text_events.clear()
        if text_input:
            return Keys(pressed=pressed, text_events=tuple(text_events))
        if blocked:
            return Keys(self.down - blocked, pressed, dx, dy)
        return Keys(set(self.down), pressed, dx, dy)

    def close(self) -> None:
        try:
            self.mouse.set_capture(False)
        finally:
            try:
                close_pointer = getattr(self.mouse.pointer, "close", None)
                if close_pointer is not None:
                    close_pointer()
            finally:
                self.api.SetConsoleMode(self.handle, self.original_input)
                self.api.SetConsoleMode(self.output, self.original_output)

    def set_mouse_capture(self, active):
        if active and not self.mouse.requested:
            # Establish a new input epoch: a queued click/focus record from
            # before pause or another foreground window cannot identify a host.
            if not self.api.FlushConsoleInputBuffer(self.handle):
                return
            # Flushing can discard key-up records, but clearing all keys would
            # stall held WASD/Shift until keyboard repeat resumes. Reconcile
            # physical state once per capture epoch, including held action keys
            # so their next repeat does not become a second UI/attack press.
            self._sync_held_keys()
        self.mouse.set_capture(active)

    def _sync_held_keys(self) -> None:
        self.down = {key for code, key in self.mapping.items()
                     if self.mouse.pointer.key_down(code)}
        if self._blocked_by_text:
            self._blocked_by_text.intersection_update(self.down)

    def set_text_input(self, enabled: bool) -> None:
        if self._text_input and not enabled:
            # Discard a queued paste tail and consume held text keys until they
            # are released, including Esc and Enter, before play resumes.
            if self.api.FlushConsoleInputBuffer(self.handle):
                self._sync_held_keys()
            self._blocked_by_text = set(self.down)
        self._text_input = enabled


class PosixKeyboard:
    """Portable raw-terminal fallback; uppercase WASD carries the Shift modifier.

    Traditional Unix terminals don't send key-up events. A short timeout models
    held keys there; Windows uses precise native events instead.
    """

    _text_input = False
    _ARROWS = {b"A": "up", b"B": "down", b"C": "right", b"D": "left"}
    _TEXT_SEQUENCES = {b"H": "home", b"1~": "home", b"7~": "home",
                       b"F": "end", b"4~": "end", b"8~": "end",
                       b"3~": "delete", b"5~": "page_up", b"6~": "page_down"}
    _TEXT_CONTROLS = {"\r": "enter", "\n": "enter", "\x08": "backspace", "\x7f": "backspace"}
    _PLAY_CONTROLS = {" ": "space", "\t": "tab", "\r": "attack", "\n": "attack", "`": "console"}
    _PLAY_KEYS = frozenset("wasdemhprf") | {"attack", "escape", "space", "tab", "left", "right",
                                                   "up", "down", "console"}

    def __init__(self):
        import termios
        import tty

        self.termios = termios
        # A terminal can give stdin and stdout duplicates of one descriptor.
        # Open our own reader so nonblocking input never affects frame writes.
        self.fd = os.open(os.ttyname(sys.stdin.fileno()), os.O_RDONLY | os.O_NONBLOCK | os.O_NOCTTY)
        try:
            self.original = termios.tcgetattr(self.fd)
            tty.setraw(self.fd)
        except BaseException:
            os.close(self.fd)
            raise
        self.expiry: dict[str, float] = {}
        self.pending = b""
        self.escape_time = 0.0

    def poll(self) -> Keys:
        now = time.perf_counter()
        self.expiry = {key: expiry for key, expiry in self.expiry.items() if expiry > now}
        previous = set(self.expiry)
        pressed: set[str] = set()
        text_events: list[str] = []
        text_input = self._text_input
        for _ in range(4):
            try:
                data = os.read(self.fd, 4096)
            except BlockingIOError:
                break
            if not data:
                break
            self.pending = (self.pending + data)[:16384]
        count = 0
        while self.pending and count < 1024:
            count += 1
            if self.pending.startswith(b"\x1b"):
                if len(self.pending) == 1:
                    if not self.escape_time:
                        self.escape_time = now
                    if now - self.escape_time < 0.035:
                        break
                    key, self.pending = "escape", b""
                elif self.pending[1:2] in (b"[", b"O"):
                    end = next((i for i in range(2, len(self.pending))
                                if 0x40 <= self.pending[i] <= 0x7E), None)
                    if end is None:
                        break
                    key = self._ARROWS.get(self.pending[end:end + 1], "")
                    if text_input:
                        key = self._TEXT_SEQUENCES.get(self.pending[2:end + 1], key)
                    self.pending = self.pending[end + 1:]
                else:
                    key, self.pending = "escape", self.pending[1:]
                self.escape_time = 0.0
            else:
                char = chr(self.pending[0])
                self.pending = self.pending[1:]
                if char == "\x03":
                    key = "escape"
                    if text_input:
                        pressed.update(("escape", "interrupt"))
                elif text_input:
                    key = char if " " <= char <= "~" else self._TEXT_CONTROLS.get(char, "")
                else:
                    key = self._PLAY_CONTROLS.get(char, char.lower())
                    if char in "WASD":
                        self.expiry["shift"] = now + 0.20
            if text_input and key != "escape":
                if key:
                    text_events.append(key)
            elif key in self._PLAY_KEYS:
                if key not in previous:
                    pressed.add(key)
                self.expiry[key] = now + 0.20
        if text_input:
            return Keys(pressed=pressed, text_events=tuple(text_events))
        return Keys(set(self.expiry), pressed)

    def set_text_input(self, enabled: bool) -> None:
        if enabled == self._text_input:
            return
        self._text_input = enabled
        self.expiry = {key: expiry for key, expiry in self.expiry.items() if key == "escape"}
        if not enabled:
            self.pending = b""
            self.escape_time = 0.0
            self.termios.tcflush(self.fd, self.termios.TCIFLUSH)

    def close(self) -> None:
        try:
            self.termios.tcsetattr(self.fd, self.termios.TCSADRAIN, self.original)
        finally:
            os.close(self.fd)


class Terminal:
    def __init__(self, max_cells: int | None = None):
        self.keyboard = None
        self.last_size = (0, 0)
        self._presented = None
        self.measure_output = False
        self.output_timing = (None, None, None)
        self.max_cells = max_cells
        self.origin = (1, 1)
        self._terminal_size = (0, 0)

    def __enter__(self) -> "Terminal":
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            raise OSError("Run 'python main.py' in a terminal. For a still frame, use --snapshot.")
        self.keyboard = WindowsKeyboard() if os.name == "nt" else PosixKeyboard()
        self.last_size = (0, 0)
        self._presented = None
        try:
            sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[?7l\x1b[0m\x1b[97;40m\x1b[2J\x1b[H")
            sys.stdout.flush()
        except BaseException:
            self.keyboard.close()
            raise
        return self

    def size(self) -> tuple[int, int]:
        try:
            # Environment overrides can be stale after a resize. Ask the
            # output device directly before using the portable fallback.
            size = os.get_terminal_size(sys.stdout.fileno())
            if size.columns < 1 or size.lines < 1:
                raise OSError("terminal returned an empty size")
        except (AttributeError, OSError, ValueError):
            size = shutil.get_terminal_size((100, 32))
        width, height = fit_viewport(size.columns, size.lines, self.max_cells)
        self._terminal_size = (size.columns, size.lines)
        self.origin = (max(1, (size.lines - height) // 2 + 1),
                       max(1, (size.columns - width) // 2 + 1))
        return width, height

    @property
    def mouse_captured(self):
        return isinstance(self.keyboard, WindowsKeyboard) and self.keyboard.mouse.captured

    @property
    def mouse_error(self):
        if isinstance(self.keyboard, WindowsKeyboard):
            mouse = self.keyboard.mouse
            if mouse.requested and not mouse.captured:
                return getattr(mouse.pointer, "capture_error", "")
        return ""

    def set_mouse_capture(self, active):
        if isinstance(self.keyboard, WindowsKeyboard):
            self.keyboard.set_mouse_capture(active)

    def draw(self, lines: list[str] | StyledFrame) -> None:
        encode_start = time.perf_counter() if self.measure_output else None
        if isinstance(lines, StyledFrame):
            width, height = lines.width, lines.height
            mode = lines.color_mode
            materials = lines.materials if mode == "color" else None
            effects = lines.effects if mode == "color" else None
            rows = [(row, bytes(style), bytes(materials[y]) if materials is not None else None,
                     bytes(effects[y]) if effects is not None else None)
                    for y, (row, style) in enumerate(zip(lines.rows, lines.styles))]
        else:
            if not lines:
                return
            width, height = len(lines[0]), len(lines)
            mode = "mono"
            rows = [(row, None, None, None) for row in lines]
        size = (width, height, self.origin, self._terminal_size)
        resized = size != self.last_size
        previous = self._presented
        baseline = previous[1] if not resized and previous is not None and previous[0] == mode else None
        top, left = self.origin
        separator = "\r\n" + (f"\x1b[{left}G" if left > 1 else "")
        parts = ["\x1b[2J"] if resized else []
        encoded = {}
        last_row = -2
        for y, row in enumerate(rows):
            # Ragged plain rows come from callers outside the rectangular
            # frame path and keep the existing full-row write behavior.
            row_width = len(row[0])
            old = baseline[y] if baseline is not None and len(baseline[y][0]) == row_width == width else None
            for start, stop in _changed_spans(old, row, row_width):
                key = row, start, stop
                fragment = encoded.get(key)
                if fragment is None:
                    fragment = encode_ansi_row(*row, mode, start, stop)
                    encoded[key] = fragment
                # Consecutive rows can use CRLF. Other spans locate the
                # cursor explicitly, including when centered in a viewport.
                parts.append(separator if start == 0 and y == last_row + 1
                             else f"\x1b[{top + y};{left + start}H")
                parts.append(fragment)
                last_row = y
        payload = "".join(parts)
        write_start = time.perf_counter() if encode_start is not None else None
        if payload:
            # Invalidate before output so a partial write can be retried.
            self._presented = None
            sys.stdout.write(payload)
            sys.stdout.flush()
        if write_start is not None:
            self.output_timing = (write_start - encode_start,
                                  time.perf_counter() - write_start if payload else 0.0,
                                  len(payload))
        self.last_size = size
        self._presented = mode, rows

    def __exit__(self, exc_type, exc, traceback) -> None:
        try:
            sys.stdout.write("\x1b[0m\x1b[?7h\x1b[?25h\x1b[?1049l")
            sys.stdout.flush()
        finally:
            if self.keyboard:
                self.keyboard.close()
