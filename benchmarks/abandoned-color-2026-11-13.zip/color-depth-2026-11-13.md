# Darker color and depth — 2026-11-13

## Request and implementation

The user reviewed the flat material palette and requested darker colors and,
more importantly, varied brightness and depth. The revised renderer uses five
cached tonal levels per material, driven by face light, distance and coarse
texture. Existing ASCII density, exact visibility/depth and collision remain
unchanged; no dependencies, game actions or sound events were added.

- Stone and wood have darker shadowed faces, textured joints/grain and reserved
  highlights. Fog darkens distant colors toward the black background.
- Rounded tree crowns use their existing surface normals for tonal shading.
  Turf has continuous world-space mottling; its color does not follow animated
  blade noise. Water has dark troughs and brighter current/foam.
- Opaque actor/weapon faces use world-oriented normal light. Gold pickup glints
  remain clear; fire's amber core/highlights stay emissive. Warning tint remains.
- Local floor contact shading samples four adjacent opaque voxel cells, with
  smooth sub-cell falloff and a fade between 12 and 16 depth units. Its cache
  retains at most 2,048 cells and invalidates with `World.box()` edits. Water,
  doors and actors do not become stale cached occluders. This is local surface
  shading, **not a global sun shadow map or dynamic cast-shadow system**.
- HUD, names, prompts, crosshair, menus and the map's clear inks are preserved.
  Base UI/map/marker inks still pass the existing 7:1 black-background contrast
  check. New deliberately darker world tones have a separate 2:1 shadow floor,
  ordered luminance and tested near/far and lit/shadow differences. No frame-time
  gate was changed. Monochrome glyphs and depth remain exact.

## Frozen control

`color-flat-control-2026-11-13.zip` preserves the **uncommitted flat-color plus
streamed-GPU engine** immediately before this revision. Keep this archive:
fd56e49 does not contain that code, and is not an interchangeable control.
Extract the archive into `shade_control_tmp` to reconstruct its `ascii3d/` tree.
Reports retain before/after source hashes; timing uses `--before-color` so both
variants actually encode colors. The utility's old default remains monochrome
before/color after for reproducing earlier comparisons.

These are incremental presentation comparisons. Original d20cd0d whole-game
performance acceptance remains open, and the separate a3d044f smooth-geometry
control is unchanged. Failed reports and raw timing samples are retained.

## Verification

- `color-depth-native-tests-2026-11-13.txt` / `.json`: **436 native-console
  tests passed**, zero failures/errors, one sandbox desktop-cursor skip. Real
  GPU hardware, native input records, collision/stairs/water, sound, loading,
  color gradients and contact-cache edit/budget behavior ran. Suite: 194.474 s;
  native runner exits 0 and records current source hashes.
- `color-depth-glyph-parity-2026-11-13.json`: **136/136** frozen-monochrome vs
  current-color frames strip to identical glyphs and final scene depths, over
  all 34 roles, maps, help/pause and wide/tall/minimum views.
- `color-depth-gpu-parity-2026-11-13.json`: **204/204 byte-identical colored
  GPU/CPU production frames**, no coverage differences. Includes evolving combat
  and varied pitch/resolution. Maximum depth error 2.85e-14; existing depth
  tolerance is unchanged.
- Initial focused color suite: **12 tests pass**, including ordered darker
  ramps, visible shadow floors, distance/face differences, material identity,
  unchanged glyphs/depth, occlusion, overlays and bounded contact-cache edits.
- Before/after code-rendered indoor, river and close-tree previews were inspected:
  the revised world is darker, surfaces have tonal separation, and prompts/HUD
  remain bright. Physical terminal appearance remains for user play review.

## Reproduction

Run timing jobs serially, with unused report paths and the same dimensions,
Python, frame count and audio mode. The 15% mean/p95 gates remain unchanged.

```powershell
$env:TMP=$PWD.Path; $env:TEMP=$PWD.Path
Expand-Archive -LiteralPath benchmarks/color-flat-control-2026-11-13.zip -DestinationPath shade_control_tmp
.\.venv-gpu\Scripts\python.exe -B tools/verify_color.py --before-source shade_control_tmp --save benchmarks/depth-next-glyphs.json
.\.venv-gpu\Scripts\python.exe -B tools/verify_gpu_renderer.py --color --save benchmarks/depth-next-gpu.json
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_color.py --before-source shade_control_tmp --before-color --renderer gpu --audio --save benchmarks/depth-next-gpu-times.json
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_color.py --before-source shade_control_tmp --before-color --renderer cpu --audio --save benchmarks/depth-next-cpu-times.json
# In a live console sized exactly 160x50:
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_color.py --before-source shade_control_tmp --before-color --renderer gpu --audio --terminal-output --width 160 --height 50 --scenes indoors meadow river warden ridge_approach --save benchmarks/depth-next-native.json
```

Native write/flush measurements use a hidden classic console, with 6x12 Consolas,
and do not establish visible Windows Terminal compositor or whole-loop FPS.

## Timing and subsequent optimization

- `color-depth-gpu-120x40-2026-11-13.json`: first complete, serial, 60-frame
  live-audio ABBA against the colored flat control, **31/34 pass**. Watchstones
  p95 +15.43%, tree close mean +16.97% and citadel roof p95 +15.76% fail the
  unchanged 15% gate. Zero underruns/recoveries, maximum refill interval 66.27 ms.
  This failed comparison is retained with all samples and source manifests.
- The follow-up removes redundant per-pixel clamps whose lighting/ripple
  inputs are already bounded to five tones. Crown color reuses its existing
  normal/fog/grain shade index, avoiding another division for every crown pixel.
  The material ramps and face, distance, texture and contact shading remain.
- `color-depth-final-focused-2026-11-13.txt`: **25 focused tests pass** after
  that optimization, including actual GPU hardware, color, edits/fallback and
  benchmark helper report preservation. `color-depth-final-gpu-parity-2026-11-13.json`
  repeats **204 exact colored GPU/CPU pairs**; `color-depth-final-glyph-parity-2026-11-13.json`
  repeats **136 exact glyph/depth pairs** on the optimized engine.
- `color-depth-gpu-optimized-120x40-2026-11-13.json`: complete recheck,
  **30/34 pass**. Meadow p95 +22.45%, grass close p95 +16.78%, tree close
  mean/p95 +17.92%/+19.29%, east meadow mean/p95 +17.58%/+20.77% fail.
  This is retained; the first clamp/crown optimization did not establish
  acceptance. The following repair chooses one cached depth ink for both
  strokes of each grass blade, and reuses turf's existing fog value instead
  of calculating a second distance division.
- `color-depth-cached-focused-2026-11-13.txt`: **60 tests pass** on the blade
  cache/fog revision, covering actual GPU hardware, color, foliage, clipping,
  depth, animation, water and movement. The cached revision again passes
  **204 exact colored GPU/CPU frames** (`color-depth-cached-gpu-parity-2026-11-13.json`)
  and **136 exact glyph/depth pairs** (`color-depth-cached-glyph-parity-2026-11-13.json`).
- `color-depth-gpu-cached-120x40-2026-11-13.json`: **31/34 pass**. Grass close
  mean/p95 +15.28%/+18.28%, tree close mean +15.14% and ravine p95 +17.25%
  fail. Retained with all samples. The next repair bounds contact checks with
  a conservative halo of the renderer's existing chunk tops: open grass with
  no possible adjacent voxel skips contact probes. The halo needs at most nine
  source reads per chunk, is cached until voxel edits, and cannot skip a real
  opaque neighbor. A regression test checks that bound across the fixture world.
