"""Exact continuous ground triangles and configurable fractional solid steps.

Camera rays use their original (possibly unnormalized) parameter. Ground is a
solid below a continuous triangulated vertex grid, independent of voxel storage.
"""

from array import array
from dataclasses import dataclass
import math


EPSILON = 1e-7


@dataclass(frozen=True, slots=True)
class SurfaceHit:
    distance: float
    material: int
    normal: tuple[float, float, float]


def grid_intervals(ox, oy, dx, dy, start, limit, size=1):
    """Visit only crossed XY cells, retaining exact entry/exit parameters."""
    t = start
    x = math.floor((ox + dx * (t + 1e-9)) / size)
    y = math.floor((oy + dy * (t + 1e-9)) / size)
    sx, sy = (1 if dx >= 0 else -1), (1 if dy >= 0 else -1)
    tx = ((x + (sx > 0)) * size - ox) / dx if abs(dx) > 1e-12 else math.inf
    ty = ((y + (sy > 0)) * size - oy) / dy if abs(dy) > 1e-12 else math.inf
    ax = abs(size / dx) if abs(dx) > 1e-12 else math.inf
    ay = abs(size / dy) if abs(dy) > 1e-12 else math.inf
    while t <= limit + 1e-9:
        end = min(tx, ty, limit)
        yield x, y, t, end
        if end >= limit:
            return
        if tx <= end + 1e-10:
            x += sx
            tx += ax
        if ty <= end + 1e-10:
            y += sy
            ty += ay
        t = end


def circle_rect(x, y, radius, x0, y0, x1, y1):
    dx, dy = max(x0 - x, 0.0, x - x1), max(y0 - y, 0.0, y - y1)
    return dx * dx + dy * dy < radius * radius + 1e-12


@dataclass(frozen=True, slots=True)
class SolidBox:
    x0: float
    y0: float
    z0: float
    x1: float
    y1: float
    z1: float
    material: int = 2

    def ray_hit(self, origin, direction, limit):
        enter, leave, normal = 0.0, limit, (0.0, 0.0, 1.0)
        for axis, (low, high) in enumerate(zip((self.x0, self.y0, self.z0),
                                               (self.x1, self.y1, self.z1))):
            o, d = origin[axis], direction[axis]
            if abs(d) < 1e-12:
                if o < low or o > high:
                    return None
                continue
            a, b = (low - o) / d, (high - o) / d
            sign = -1.0
            if a > b:
                a, b, sign = b, a, 1.0
            if a > enter:
                enter = a
                normal = tuple(sign if i == axis else 0.0 for i in range(3))
            leave = min(leave, b)
            if enter > leave + 1e-10:
                return None
        return SurfaceHit(max(0.0, enter), self.material, normal) if leave >= 0 else None

    def overlaps(self, x, y, feet, radius, height):
        return (feet < self.z1 - EPSILON and feet + height > self.z0 + EPSILON
                and circle_rect(x, y, radius, self.x0, self.y0, self.x1, self.y1))


class HeightField:
    CHUNK = 8

    def __init__(self, width, depth, heights, material=5):
        self.width, self.depth = width, depth
        self.heights = array("d", heights)
        if len(self.heights) != (width + 1) * (depth + 1):
            raise ValueError("heightfield needs one height at every grid vertex")
        if not all(math.isfinite(v) and v >= 0 for v in self.heights):
            raise ValueError("heightfield heights must be finite and nonnegative")
        self.materials = bytearray([material]) * (width * depth)
        self.enabled = bytearray([1]) * (width * depth)
        self._chunks = {}
        self._footprints = {}
        self._maximum = max(self.heights, default=0.0)
        self.revision = 0

    def _corners(self, x, y):
        i = y * (self.width + 1) + x
        h = self.heights
        return h[i], h[i + 1], h[i + self.width + 1], h[i + self.width + 2]

    def cell_bounds(self, x, y):
        values = self._corners(x, y)
        return min(values), max(values)

    def _plane(self, x, y, second=False):
        h00, h10, h01, h11 = self._corners(x, y)
        return (h11 - h01, h01 - h00, h00) if second else (h10 - h00, h11 - h10, h00)

    def height_at(self, x, y):
        cx, cy = math.floor(x), math.floor(y)
        if not (0 <= cx < self.width and 0 <= cy < self.depth
                and self.enabled[cy * self.width + cx]):
            return None
        u, v = x - cx, y - cy
        a, b, c = self._plane(cx, cy, v > u)
        return c + a * u + b * v

    def material_at(self, x, y):
        cx, cy = math.floor(x), math.floor(y)
        if 0 <= cx < self.width and 0 <= cy < self.depth and self.enabled[cy * self.width + cx]:
            return self.materials[cy * self.width + cx]
        return 0

    def paint_cell(self, x, y, material):
        if 0 <= x < self.width and 0 <= y < self.depth:
            self.materials[y * self.width + x] = material
            self.revision += 1
            self._footprints.clear()

    def edit_box(self, x0, y0, z0, x1, y1, z1, material):
        """Authored voxels and cuts replace touched surface cells; turf repaints."""
        for y in range(max(0, y0), min(self.depth, y1)):
            for x in range(max(0, x0), min(self.width, x1)):
                i = y * self.width + x
                if not self.enabled[i]:
                    continue
                low, high = self.cell_bounds(x, y)
                if z0 < high - 1e-8 and z1 >= low - 1e-8:
                    if material in (5, 9):
                        self.materials[i] = material
                    else:
                        self.enabled[i] = 0
                        self._chunks.pop((x // self.CHUNK, y // self.CHUNK), None)
        self.revision += 1
        self._footprints.clear()

    def _chunk_bounds(self, cx, cy):
        key = cx, cy
        if key not in self._chunks:
            low, high = math.inf, -math.inf
            for y in range(max(0, cy * self.CHUNK), min(self.depth, (cy + 1) * self.CHUNK)):
                for x in range(max(0, cx * self.CHUNK), min(self.width, (cx + 1) * self.CHUNK)):
                    if self.enabled[y * self.width + x]:
                        a, b = self.cell_bounds(x, y)
                        low, high = min(low, a), max(high, b)
            self._chunks[key] = low, high
        return self._chunks[key]

    def prepare(self):
        for cy in range((self.depth + self.CHUNK - 1) // self.CHUNK):
            for cx in range((self.width + self.CHUNK - 1) // self.CHUNK):
                self._chunk_bounds(cx, cy)

    def ray_hit(self, origin, direction, limit, minimum=0.0):
        ox, oy, oz = origin
        dx, dy, dz = direction
        if min(oz, oz + dz * limit) > self._maximum + EPSILON:
            return None
        start, end = minimum, limit
        for o, d, high in ((ox, dx, self.width), (oy, dy, self.depth)):
            if abs(d) < 1e-12:
                if not 0 <= o < high:
                    return None
            else:
                a, b = -o / d, (high - o) / d
                start, end = max(start, min(a, b)), min(end, max(a, b))
        if start > end or end < 0:
            return None
        for chunk_x, chunk_y, a, b in grid_intervals(ox, oy, dx, dy, start, end, self.CHUNK):
            low, high = self._chunk_bounds(chunk_x, chunk_y)
            if low == math.inf or min(oz + dz * a, oz + dz * b) > high + EPSILON:
                continue
            for x, y, left, right in grid_intervals(ox, oy, dx, dy, a, b):
                if not (0 <= x < self.width and 0 <= y < self.depth):
                    continue
                index = y * self.width + x
                if not self.enabled[index]:
                    continue
                u, v = ox + dx * left - x, oy + dy * left - y
                aa, bb, cc = self._plane(x, y, v > u)
                if oz + dz * left < cc + aa * u + bb * v - EPSILON:
                    return SurfaceHit(max(0.0, left), self.materials[index], (0.0, 0.0, 1.0))
                nearest = None
                for second in (False, True):
                    aa, bb, cc = self._plane(x, y, second)
                    denominator = dz - aa * dx - bb * dy
                    if denominator >= -1e-12:
                        continue
                    t = (cc + aa * (ox - x) + bb * (oy - y) - oz) / denominator
                    if left - 1e-8 <= t <= right + 1e-8 and t >= -1e-8:
                        u, v = ox + dx * t - x, oy + dy * t - y
                        if (v >= u - 1e-8) if second else (v <= u + 1e-8):
                            length = math.sqrt(aa * aa + bb * bb + 1)
                            candidate = SurfaceHit(max(0.0, t), self.materials[index],
                                                   (-aa / length, -bb / length, 1 / length))
                            if nearest is None or candidate.distance < nearest.distance:
                                nearest = candidate
                if nearest is not None:
                    return nearest
        return None

    def footprint(self, x, y, radius, with_grade=False):
        """Exact maximum of each ground triangle intersecting a circular foot."""
        key = x, y, radius
        if key in self._footprints:
            values = self._footprints[key]
            return values if with_grade else tuple((top, material) for top, material, _ in values)
        results = []
        for cy in range(max(0, math.floor(y - radius)), min(self.depth, math.floor(y + radius) + 1)):
            for cx in range(max(0, math.floor(x - radius)), min(self.width, math.floor(x + radius) + 1)):
                index = cy * self.width + cx
                if not self.enabled[index] or not circle_rect(x, y, radius, cx, cy, cx + 1, cy + 1):
                    continue
                for second in (False, True):
                    vertices = ((cx, cy), (cx, cy + 1), (cx + 1, cy + 1)) if second else (
                        (cx, cy), (cx + 1, cy), (cx + 1, cy + 1))
                    aa, bb, cc = self._plane(cx, cy, second)
                    candidates = []
                    def inside(px, py):
                        return (cx - 1e-9 <= px <= cx + 1 + 1e-9
                                and cy - 1e-9 <= py <= cy + 1 + 1e-9
                                and ((py - cy >= px - cx - 1e-9) if second
                                     else (py - cy <= px - cx + 1e-9)))
                    if inside(x, y):
                        candidates.append((x, y))
                    gradient = math.hypot(aa, bb)
                    if gradient:
                        px, py = x + radius * aa / gradient, y + radius * bb / gradient
                        if inside(px, py):
                            candidates.append((px, py))
                    for i, (px, py) in enumerate(vertices):
                        if (px - x) ** 2 + (py - y) ** 2 <= radius * radius + 1e-10:
                            candidates.append((px, py))
                        qx, qy = vertices[(i + 1) % 3]
                        ex, ey = qx - px, qy - py
                        offset_x, offset_y = px - x, py - y
                        qa = ex * ex + ey * ey
                        qb = 2 * (offset_x * ex + offset_y * ey)
                        qc = offset_x * offset_x + offset_y * offset_y - radius * radius
                        discriminant = qb * qb - 4 * qa * qc
                        if discriminant >= 0:
                            root = math.sqrt(discriminant)
                            for t in ((-qb - root) / (2 * qa), (-qb + root) / (2 * qa)):
                                if -1e-9 <= t <= 1 + 1e-9:
                                    candidates.append((px + t * ex, py + t * ey))
                    if candidates:
                        top = max(cc + aa * (px - cx) + bb * (py - cy) for px, py in candidates)
                        results.append((top, self.materials[index], aa * aa + bb * bb))
        if len(self._footprints) >= 512:
            self._footprints.clear()
        self._footprints[key] = tuple(results)
        values = self._footprints[key]
        return values if with_grade else tuple((top, material) for top, material, _ in values)
