# Project Status

Last reviewed: **2026-11-14**. Standing rules: [AGENTS.md](AGENTS.md).
User backlog: [backlog.md](backlog.md). Launch/controls: [README.md](README.md).

## Current checkpoint

- **Rich color is implemented on the existing map**, at the user's request to
  move color ahead of the unfinished world rebuild. The earlier grayscale-review
  gate is superseded. The user also authorized overriding the standing usage
  cutoff for this color pass; do not infer that exception for other sessions.
- `--color-mode color|gray|mono` defaults to color. Materials have rich hues;
  foreground brightness follows normals/distance; fog cools distant surfaces;
  exact-LOS firelight warms visible surfaces. Stone/straw/bone/timber/metal,
  purple rune crystals, hot fire cores and dimmer embers carry explicit identities.
  Black backgrounds, shared opaque depth tests, plain snapshots, pause/help,
  resizing, E interaction and existing sound events remain.
- `StyledFrame` carries compact level/material/effect buffers. Color and grayscale
  serialization share dimensions and reset behavior. Cache-safe material map
  symbols, health colors and E/player-marker accents preserve textual cues.
- The construction kit and six-destination gothic world remain **unimplemented**.
  No map, physics, enemy AI, objectives or save system was added in this pass.
  Approved world brief: [redesign checkpoint](benchmarks/visual-redesign-2026-11-14.md).
- Foundation is committed at **fe42316**. Color changes remain uncommitted pending
  successful user review. `benchmarks/color-control-2026-11-14.zip` preserves
  90 SHA256-verified pre-color working files; it is an incremental comparison
  source, not a replacement for historical accepted performance references.

## Latest verification

- **508-test native-console suite passed**, zero failures/errors, one sandbox
  ClipCursor skip; 163.678 seconds. Native handles and unchanged source hashes
  verified. `color-native-tests-2026-11-14.txt/.json` retain evidence.
- **204 complete CPU/GPU frame pairs across 34 roles pass**: glyphs, luminance,
  materials, fog/warm effects, color/grayscale ANSI and exact depths all agree.
  No errors or source changes, GPU remains healthy. Report:
  `benchmarks/color-gpu-parity-2026-11-14.json`.
- Six software-rendered scenes inspected (exterior, canopy, river, hall, fireballs,
  Warden). This is not the user's physical terminal/font/play approval. Snapshot,
  fallback, metadata, clipping, small/large viewport and hidden-effect tests pass.
- Incremental 120x40/60-frame styled-render+ANSI/live-audio ABBA against the
  frozen grayscale source: **CPU 34/34 passes**, max mean/p95 +8.42%/+13.35%;
  **GPU 30/34 passes**, with courtyard/lodge/tree_canopy/ridge_roof p95 failures.
  Both runs are complete, zero audio underruns/recoveries, unchanged 15% gates
  and source hashes. The GPU performance gate is **not accepted**.
- Four actual native GPU apps (60 frames each), gray control/current color at
  120x40 and 160x50, all pass. Demo moves, dimensions match, audio has zero
  underruns/recoveries, colors/black background and modes/cursor/screen restore
  are verified. Actual matched host font is ����ü 8x16 (Consolas request substituted).
  Color uncapped loop work mean/p95: 26.53/37.04 ms and 37.74/51.68 ms respectively.
  Native diagnostics retain raw bytes, times and differing poses; they are not
  fixed-simulation ABBA acceptance or physical speaker/terminal play approval.
- Tail-attribution probes failed before timing (including native invalid handle
  during frozen GPU adapter enumeration). Zero samples; no GC/GPU-wait cause
  was established. All failed artifacts remain. No validation jobs remain.
  Helpers, previews, caches and extracted control are removed; ZIP preserved.
  Full evidence: [color pass](benchmarks/color-pass-2026-11-14.md).

## Open issues and limits

- **Historical performance remains unresolved.** Earlier grayscale foundation
  CPU 1/34 and GPU 4/34 role gates failed; d20cd0d acceptance remains 14/24. The current
  40 FPS cap does not establish sustained 40 FPS. Do not relax the 15% mean/p95 limits
  or promote this expensive grayscale control to an accepted baseline.
- World rebuilding, remaining blockiness and the separate sound overhaul remain
  open. Old lag position (215.2,187.4,Z10) overlaps old geometry; its retained
  audio-off diagnostic is not a playable-camera benchmark or proven reproduction.
- Physical mouse capture/speaker quality, actual fullscreen font/layout, POSIX
  held-key behavior and Python 3.10 execution remain unverified. CPU needs no extra
  packages; optional wgpu 0.33.0 uses Python 3.11+.

## Resume / review commands

Use a native console for input checks; run timing jobs serially with unused paths.

```powershell
$env:TMP=$PWD.Path; $env:TEMP=$PWD.Path
$env:MONOLITH_GPU_TESTS='1'; $env:MONOLITH_DESKTOP_TESTS='1'
.\.venv-gpu\Scripts\python.exe -B -m unittest discover -s tests -v
.\.venv-gpu\Scripts\python.exe -B main.py --renderer gpu --color-mode color
python -B main.py --renderer cpu --color-mode gray --keyboard-look
# Reconstruct the pre-color control only if absent:
Expand-Archive -LiteralPath benchmarks/color-control-2026-11-14.zip -DestinationPath color_control_tmp
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_same_geometry.py --before-source color_control_tmp --before-renderer cpu --after-renderer cpu --frames 60 --audio --presentation styled --before-color-mode gray --after-color-mode color --save benchmarks/color-next-cpu-unused.json
.\.venv-gpu\Scripts\python.exe -B tools/benchmark_same_geometry.py --before-source color_control_tmp --before-renderer gpu --after-renderer gpu --frames 60 --audio --presentation styled --before-color-mode gray --after-color-mode color --save benchmarks/color-next-gpu-unused.json
```

Required older evidence stays linked in [benchmarks/README.md](benchmarks/README.md).
